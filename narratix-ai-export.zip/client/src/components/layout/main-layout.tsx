// File to be deleted
